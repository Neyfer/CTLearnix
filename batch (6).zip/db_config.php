<?php
// Credenciales universales de conexión a la base de datos
$db_host = "localhost";
$db_user = "root";
$db_pass = "Copi.2005";

// Nombre de la base de datos maestra para usuarios, configuraciones globales, y lista de años
$master_db_name = "schooltest_master_db"; 
// Asegúrate de crear esta base de datos en MySQL/MariaDB y darle permisos al usuario 'root'.
?>