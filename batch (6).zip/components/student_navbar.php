<div class="relative z-10 flex-shrink-0 flex h-16 bg-white shadow-md md:hidden">
    <button type="button" id="mobile-menu-button" class="px-4 border-r border-gray-200 text-gray-500 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500 md:hidden">
        <i class="fas fa-bars fa-lg"></i>
    </button>
    <div class="flex-1 px-4 flex justify-between">
        <div class="flex-1 flex items-center">
            <span class="font-bold text-indigo-600">Portal Estudiantil</span>
        </div>
        </div>
</div>